package com.springmvc.bean;

/**

This class creates object of PropertyReading class which is responsible for loading and manipulating property file.It also provide methods (API) to validate 
email address,Date,Maximum length of input field .Validation rules are extracted from property file.
 *
 *
 */
/**
 * @author ankush
 *
 */

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class ValidateInput {
	private PropertyReading propertyObject;

	
	
	// Constructor
	// ---------------------------------------------------------------------------------------------/
	public ValidateInput() {
		propertyObject = new PropertyReading();
		


	}

	// ----------------------------------------------------------------------------------------/
	public ReturnType validateEmail(String email) {
		ReturnType returnObject = new ReturnType();
		int lastIndex = email.lastIndexOf("@");

		String domain = email.substring(lastIndex);
		String emailType = propertyObject.getEmailPattern();

		if (emailType.equals("")) {

		
          propertyObject.logger.severe("Entry for domain name(Eg: ankush@gmail.com) etc in property file for emailAddress key");
			throw new NullPointerException("Email rule is not available in file");
           // returnObject.errorMessage = new String("Conguration file error");           //can also return this

		

		} else {
			int index = emailType.lastIndexOf("@");
			String reqDomain = emailType.substring(index);
			if (domain.equals(reqDomain)) {

				returnObject.validationStatus = true;
				returnObject.errorMessage = null;
				return returnObject;
			} else {
				returnObject.validationStatus = false;
				returnObject.errorMessage = propertyObject.getEmailMsg();

				return returnObject;
			}

		}
	}

	/**
	 * This function validate date by checking whether date entered or selected
	 * by user satisfies the minimum and maximum date requirements.It also
	 * checks whether user entered date also satisfies maximum and minimum year
	 * requirement
	 * @throws ParseException 
	 * @throws NullPointerException 
	 */
	// ----------------------------------------------------------------------------------------/

	public ReturnType validateDate(String date) throws NullPointerException, ParseException {
		ReturnType returnObject = new ReturnType();
		if(date==null){throw new NullPointerException();
		}
		Date d = convertToDate(date);
		if (d == null) {
			returnObject.validationStatus=false;
		
			returnObject.errorMessage = "Enter the date in DD-MM-YY format";
			return returnObject;
		}else
		return (validateDate(d));

	}

	// ----------------------------------------------------------------------------------------/

	public ReturnType validateDate( Date  date )       throws ParseException  {

		
		ReturnType returnObject ;
		if (date == null) {
			
			throw  new NullPointerException();
			
			//returnObject.errorMessage = new String("Plese enter the date");
			//return returnObject;
		}
		
		try{
			
			returnObject =checkMinYearLimit(date);
			if(returnObject.validationStatus==false && returnObject.errorMessage!=null){
				return returnObject;
				
			}
			returnObject =checkMaxYearLimit(date);
			if(returnObject.validationStatus==false && returnObject.errorMessage!=null){
				return returnObject;
				
			}
			
			returnObject =checkMaxDateLimit(date);
			if(returnObject.validationStatus==false && returnObject.errorMessage!=null){
				return returnObject;
				
			}
			returnObject =checkMinDateLimit(date);
			if(returnObject.validationStatus==false && returnObject.errorMessage!=null){
				return returnObject;
				
			}
			return returnObject;
		}catch(NullPointerException e){throw e;}
		
		
		}
	
			 
		

	// ----------------------------------------------------------------------/

	private ReturnType checkMinYearLimit(Date d ) {
		ReturnType returnObject = new ReturnType();
		String minYear = propertyObject.getMinYeare();

		if (minYear.equals("")){
		propertyObject.logger.severe("Unable to read minimum year configuration form configuration file");
			throw new NullPointerException();              //Throwing an exception to controller
		}else {
		

			long minYearLimit = Integer.parseInt(minYear);

			d = setTimeToMidnight(d);
			long year = getYearFromDate(d);
			if (year < minYearLimit) {
			
				String minYearLimitMsg = propertyObject.getMinYeareMsg();

				returnObject.errorMessage = minYearLimitMsg;
				returnObject.validationStatus = false;
				return returnObject;
			}
			else{
				returnObject.errorMessage =null;
				returnObject.validationStatus =true;
				return returnObject;
			
			}
			
		}
		}
	

		
	
	

	// ----------------------------------------------------------------------/

	private ReturnType checkMaxYearLimit(Date d) {
		ReturnType returnObject = new ReturnType();
		String maxYear = propertyObject.getMaxYeare();

		if (maxYear.equals("")){
			propertyObject.logger.severe("Unable to read maximum  year value form configuration file");
			throw new NullPointerException();              //Throwing an exception to controller
		}else {
			long maxYearLimit = Integer.parseInt(maxYear);

			d = setTimeToMidnight(d);
			long year = getYearFromDate(d);
			if (year>maxYearLimit) {
			
				String minYearLimitMsg = propertyObject.getMinYeareMsg();

				returnObject.errorMessage = minYearLimitMsg;
				returnObject.validationStatus = false;
				return returnObject;
			}
			else{
				returnObject.errorMessage =null;
				returnObject.validationStatus =true;
				return returnObject;
			
			}
	}
		}

	// ----------------------------------------------------------------------/

	private ReturnType checkMinDateLimit(Date input) {

		ReturnType returnObj = new ReturnType();

		String minDate = propertyObject.getMinDate();

		if (minDate.equals("")){
		propertyObject.logger.severe("Unable to read minimum date from property file");
		throw new NullPointerException();
		
		} else{
			Date minDateObj = convertToDate(minDate);
			if (minDateObj != null) {

				input = setTimeToMidnight(input);

				minDateObj = setTimeToMidnight(minDateObj);

				int diff = input.compareTo(minDateObj);
				
				
			    	if (diff >= 0) {
					returnObj.validationStatus = true;
					returnObj.errorMessage = null;

					return returnObj;
			    	} else {
					returnObj.validationStatus = false;
					returnObj.errorMessage = propertyObject.getMinDateMsg();
					return returnObj;
			    	}
			}
			
			else {
				returnObj.validationStatus = false;
				propertyObject.logger.severe("Unable to parse string to object");
				returnObj.errorMessage ="Unable to interpret configuration for date";                    //unable to interpret date.
				return returnObj;
			
			}
			}

		}
	

	// ----------------------------------------------------------------------/

	private ReturnType checkMaxDateLimit(Date input) throws ParseException {

		ReturnType returnObj = new ReturnType();

		String maxDate = propertyObject.getMaxDate();

		if (maxDate.equals("")){
		propertyObject.logger.severe("Unable to read maximum date from property file");
		throw new NullPointerException();
		
		} else{
			Date maxDateObj = convertToDate(maxDate);
			if (maxDateObj != null) {

				input = setTimeToMidnight(input);

				maxDateObj = setTimeToMidnight(maxDateObj);

				int diff = input.compareTo(maxDateObj);
				
				
			    	if (diff > 0) {
			    	returnObj.validationStatus = false;
					returnObj.errorMessage = propertyObject.getMinDateMsg();
					return returnObj;
			    	
					} else {
						returnObj.validationStatus = true;
			
					returnObj.errorMessage = null;

					return returnObj;
					}
			}
			
			else {
		
				propertyObject.logger.severe("Unable to parse string to object");
			        throw new ParseException("Unable to parse date string",111);    
			}
			}

		}
	
	// This function sets all time parameters to null in date object i.e this
	// give date without time
	// ----------------------------------------------------------------------/
	public Date setTimeToMidnight(Date date) {
		Calendar calendar = Calendar.getInstance();

		calendar.setTime(date);
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);

		return calendar.getTime();
	}

	/** This function return a year from date object.It is used as function in
	** date class to get corresponding year is deprecated
	**/
	// ----------------------------------------------------------------------/
	public long getYearFromDate(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		long year = calendar.get(Calendar.YEAR);

		return year;

	}

	/**
	 * Here is code to check whether user input satisfies the requirement of
	 * maximum length of field
	 */
	// ----------------------------------------------------------------------/
	public ReturnType checkLenth(String strlenth) {
		int maxLenth;
		ReturnType returnObject = new ReturnType();
		String Lenth = propertyObject.getMaxLenth();
		if (Lenth.equals("")) {
			
				propertyObject.logger.warning("You have have not set lenth  rule in property file");
			return returnObject;
		} else {
			maxLenth = Integer.parseInt(Lenth);
		}

		if (strlenth.length() != maxLenth) {
			returnObject.errorMessage = propertyObject.getMaxLenthMsg();
			returnObject.validationStatus = false;
			return returnObject;
		} else {
			returnObject.validationStatus = true;
			returnObject.errorMessage = null;
			return returnObject;
		}
	}

	// ----------------------------------------------------------------------/

	public ReturnType checkStart(String input) {
		ReturnType returnObject = new ReturnType();
		String startUp = new String(propertyObject.getStart());
		Pattern p = Pattern.compile(startUp);
		Matcher m = p.matcher(input);
		if (m.find()) {

			returnObject.errorMessage = null;
			returnObject.validationStatus = true;
			return returnObject;

		} else {

			returnObject.errorMessage = propertyObject.getStartMsg();
			returnObject.validationStatus = false;
			return returnObject;

		}

	}

	// ----------------------------------------------------------------------/

	public ReturnType validateString(String key, String inputString) {
		
		ReturnType returnObject = new ReturnType();

		String regEx = propertyObject.getValue(key);
		
		Pattern stringPattern = Pattern.compile(regEx);
		
		Matcher match = stringPattern.matcher(inputString);
		
		if (match.find()) {
			
			returnObject.errorMessage = null;
			
			returnObject.validationStatus = true;
			
			return returnObject;
		} else {
			
			returnObject.errorMessage = "Input string is not valid";			
			returnObject.validationStatus = false;
			
			return returnObject;
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	// ----------------------------------------------------------------------/

	public Date convertToDate(String date) {

		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");

		Date dateObject=null;
	
		try {
			dateObject = (Date) sdf.parse(date);              
		} catch (ParseException e) {
			propertyObject.logger.severe("You need to enter date in dd-MM-yy format in property file only (Do not use name for month, use numbers)");
			
            
		} catch (NullPointerException e) {
			propertyObject.logger.severe("unable to parse date string");
			
		}

		return dateObject;
	}

	// ----------------------------------------------------------------------/
	public void setProperties(String[] keys, String[] values) {

		propertyObject.setProperties(keys, values);

	}


	
}
