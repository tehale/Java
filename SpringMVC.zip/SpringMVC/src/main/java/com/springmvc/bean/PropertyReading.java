package com.springmvc.bean;


/**
This class provided interface with back end it may be database or external property file.In this case property file is used as source of backend data.
It loads property  file and sets default values for rule. Most of method in this returns rules set in external property file.
 *
 */
/**
 *  @author ankush
 */

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PropertyReading {
	private Properties prop;
	Logger logger;
	FileHandler handler;

//constructer 
	public PropertyReading()  {
		logger=Logger.getLogger("");
		 try {
			handler=new FileHandler("log.txt");
			prop = new Properties();

			prop.load(new FileInputStream("config.properties"));
		} catch (SecurityException e) {
		
			e.printStackTrace();
		} catch (IOException e) {
			logger.severe("IO exception occured during creating Properties file");
	
		logger.addHandler(handler);
		logger.setLevel(Level.ALL);

		}

		}
	// Constructor ends here

	// ----------------------------------------------------------------------------------------/
	public String getEmailPattern() {
		if (prop.getProperty("emailAddress") == null) {
			logger.warning("Value for email address is not set");
		}
		return (prop.getProperty("emailAddress"));
	}

	// ----------------------------------------------------------------------------------------/
	public String getEmailMsg() {

		return (prop.getProperty("emailAddressMsg"));

	}

	// ----------------------------------------------------------------------------------------/
	public String getMinDate() {

		return (prop.getProperty("minDate"));
	}

	// ----------------------------------------------------------------------------------------/
	public String getMaxDate() {

		return (prop.getProperty("maxDate"));
	}

	// ----------------------------------------------------------------------------------------/
	public String getMaxYeare() {
		return (prop.getProperty("maxYear"));
	}

	// ----------------------------------------------------------------------------------------/
	public String getMinYeare() {

		return (prop.getProperty("minYear"));
	}

	// ----------------------------------------------------------------------------------------/
	public String getMaxDateMsg() {

		return (prop.getProperty("maxDateMsg"));

	}

	// ----------------------------------------------------------------------------------------/
	public String getMinDateMsg() {

		return (prop.getProperty("minDateMsg"));
	}

	// ----------------------------------------------------------------------------------------/
	public String getMaxYeareMsg() {
		return (prop.getProperty("maxYearMsg"));
	}

	// ----------------------------------------------------------------------------------------/
	public String getMinYeareMsg() {
		return (prop.getProperty("minYearMsg"));
	}

	// ----------------------------------------------------------------------------------------/
	public String getMaxLenth() {
		return (prop.getProperty("maxLenth"));
	}

	// ----------------------------------------------------------------------------------------/
	public String getMaxLenthMsg() {
		return (prop.getProperty("maxLenthMsg"));
	}

	// ----------------------------------------------------------------------------------------/
	public void setProperty(String key, String value) {

		prop.setProperty(key, value);
		try {
			prop.store(new FileOutputStream("config.properties"), null);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException i) {
			i.printStackTrace();
		}
	}

	// ----------------------------------------------------------------------------------------/
	public void setProperties(String[] key, String[] value) {
		for (int i = 0; i < key.length; i++) {
			prop.setProperty(key[i], value[i]);
		}
		try {
			prop.store(new FileOutputStream("config.properties"), null);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException i) {
			i.printStackTrace();
		}
	}

	

	// --------------------------------------------------------------------------------------------/
	// This function returns value of text start up rule set in property file

	public String getStart() {

		return (prop.getProperty("textStartUp"));
	}

	// --------------------------------------------------------------------------------------------/
	public String getStartMsg() {

		return (prop.getProperty("textStartUpMsg"));
	}
	
	// ----------------------------------------------------------------------------------------/

	public String getValue(String key){
		
		prop.getProperty(key);
		return key;
		
		
	}
	
	
	
	
	
	
	
}
