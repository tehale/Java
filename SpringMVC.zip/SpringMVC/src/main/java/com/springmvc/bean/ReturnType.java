package com.springmvc.bean;

/**This is sample for returning value in project
 * 
 */

/**
 * @author ankush
 *
 */
public class ReturnType {

	public boolean validationStatus;
	public String errorMessage;

	public ReturnType() {

		validationStatus = false;
		errorMessage = null;
	}

	public ReturnType(String errorMsg) {

		validationStatus = false;
		errorMessage = errorMsg;
	}

}
