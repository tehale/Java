/**
 * 
 */
package com.springmvc.controller;

/**
 * @author ankush
 *
 */
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.springmvc.bean.UserData;

@Controller
@RequestMapping("/")
public class Usercontroller {
	
	
	public Usercontroller(){}
	
@RequestMapping("/")
public String anyUrl(){
	
	return "index";
}
	
@RequestMapping("/sampleform")
public String sampleForm(ModelMap model){
	
	model.addAttribute("user", new UserData());
	return "sampleform";
	
}





}
