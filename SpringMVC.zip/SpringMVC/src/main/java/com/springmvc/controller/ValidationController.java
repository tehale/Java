/**
 * 
 */
package com.springmvc.controller;

/**
 *
 *
 */
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.springmvc.bean.ReturnType;
import com.springmvc.bean.UserData;
import com.springmvc.bean.ValidateInput;

@Controller
@RequestMapping(value="/sampleform")
public class ValidationController {

	List<ReturnType> errorMsg;

	@RequestMapping(value="/validate",method = RequestMethod.GET)
	public ModelAndView validateform(@ModelAttribute("user") UserData sampleuser) {

		// ReturnType errorObject =new ReturnType();

		ValidateInput inputValidator = new ValidateInput();

		this.errorMsg = new ArrayList<ReturnType>();

		/**
		 * creating object of validation class which validate inputs and also
		 * throws ioException and parse exception
		 */
		errorMsg.add(inputValidator.validateEmail(sampleuser.getEmail()));

		try {
			errorMsg.add(inputValidator.validateDate(sampleuser
					.getDateofbirth()));
		} catch (ParseException e) {

		}
		errorMsg.add(inputValidator.checkStart(sampleuser.getStudentid()));
		
		errorMsg.add(inputValidator.checkLenth(sampleuser.getAccountnumber()));

		return new ModelAndView("validuser", "error", errorMsg);

	}

}
