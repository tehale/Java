(function($,W,D)
{
    var JQUERY = {};

    JQUERY.UTIL =
    {
        setupFormValidation: function()
        {
            //form validation rules
            $("#register-form").validate({
                rules: {
                    firstname: "required",
                    lastname: "required",
                    email: {
                        required: true,
                        email: true
                    },
                    password: {
                        required: true,
                        minlength: 5
                    },
                    dateOfBirth:"required",
                    studentid:"required",
                    accountNumber:"required"
                },
                messages: {
                    firstname: "Please enter your firstname",
                    lastname: "Please enter your lastname",
                    password: {
                        required: "Please provide a password",
                        minlength: "Your password must be at least 5 characters long"
                    },
                    email: "Please enter a valid email address",
                   dateOfBirth:"plese enter date of birth",
                	   studentid:"Enter Student id example ST-30303",
                	   accountNumber:"Please enter 12 digit account number"
                },
                submitHandler: function(form) {
                    form.submit();
                }
            });
        }
    }

    //when the dom has loaded setup form validation rules
    $(D).ready(function($) {
        JQUERY.UTIL.setupFormValidation();
    });

})(jQuery, window, document);